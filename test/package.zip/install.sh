cp /storage/sdcard0/deepmod/priv-app/deep.prop /system/priv-app/
chmod 644 /system/priv-app/deep.prop